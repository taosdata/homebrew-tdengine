package com.taosdata.jdbc.enums;

public enum TimestampFormat {
    STRING,
    TIMESTAMP,
    UTC
}
