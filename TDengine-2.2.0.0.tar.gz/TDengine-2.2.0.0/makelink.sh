${csudo} chmod 777 /usr/local/cellar/tdengine/2.2.0.0/driver/libtaos.2.2.0.0.dylib
${csudo} ln -sf /usr/local/Cellar/tdengine/2.2.0.0/driver/libtaos.2.2.0.0.dylib /usr/local/lib/libtaos.1.dylib
${csudo} ln -sf /usr/local/lib/libtaos.1.dylib /usr/local/lib/libtaos.dylib
