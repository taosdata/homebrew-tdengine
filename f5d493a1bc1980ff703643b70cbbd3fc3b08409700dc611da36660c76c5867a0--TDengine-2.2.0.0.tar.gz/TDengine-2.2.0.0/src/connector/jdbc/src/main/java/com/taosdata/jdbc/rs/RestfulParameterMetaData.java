package com.taosdata.jdbc.rs;

import com.taosdata.jdbc.AbstractParameterMetaData;

public class RestfulParameterMetaData extends AbstractParameterMetaData {

    RestfulParameterMetaData(Object[] parameters) {
        super(parameters);
    }
}
